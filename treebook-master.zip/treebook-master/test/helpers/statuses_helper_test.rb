require 'test_helper'

class StatusesHelperTest < ActionView::TestCase
end
